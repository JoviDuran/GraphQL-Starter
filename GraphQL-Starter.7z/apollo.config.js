module.exports = {
  service: {
    name: 'GraphQL-Starter',
    endpoint: {
      url: 'http://localhost:8080/graphql',
    },
  },
};
