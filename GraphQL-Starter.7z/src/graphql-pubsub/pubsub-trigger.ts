export enum PubSubTrigger {
  DUMMY_EVENT = 'DUMMY_EVENT',
}
