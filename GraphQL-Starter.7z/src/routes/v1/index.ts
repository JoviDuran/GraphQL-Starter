import { maintenanceRouter } from './maintenance.routes';

export const routes = [maintenanceRouter];
