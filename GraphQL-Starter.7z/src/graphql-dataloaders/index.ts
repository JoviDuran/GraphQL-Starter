import { userByIdLoader } from '../modules/user/graphql/data-loaders/user-by-id.dataloader';
import * as coreServices from '@app/core/services';

export const initLoaders = (services: typeof coreServices) => {
  const loaders = {
    userById: userByIdLoader(services),
  };

  return loaders;
};
