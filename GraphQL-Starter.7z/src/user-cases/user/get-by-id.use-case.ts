import { userFactory } from 'src/modules/user/user.factory';
import { userRepository } from 'src/modules/user/user.repository';

export async function getById(id: string) {
  const user = await userRepository.getById(id);

  const userDTO = userFactory.toDTO(user);

  return { userDTO };
}
