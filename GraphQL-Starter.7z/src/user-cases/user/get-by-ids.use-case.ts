import { userFactory } from 'src/modules/user/user.factory';
import { userRepository } from 'src/modules/user/user.repository';

export async function getByIds(ids: string[]) {
  const users = await userRepository.getByIds(ids);

  const usersDTO = users.map((x) => userFactory.toDTO(x));

  return { usersDTO };
}
