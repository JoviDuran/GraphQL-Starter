import { Maybe, UserSortField } from 'app-graphql-schema-types';
import { OrderByDirection } from 'objection';
import { IPageInfo } from 'src/core/interfaces';
import { UserEntity } from 'src/modules/user/user.entity';
import { userRepository } from 'src/modules/user/user.repository';

interface IUserCursorPaginatedArgs {
  before?: Maybe<string>;
  after?: Maybe<string>;
  first: number;
  sortDirection: OrderByDirection;
  sortField: UserSortField;
}

// interface IUser {
//   id: string;
//   firstName: string;
//   middleName: string;
//   lastName: string;
//   fullName: string;
//   username: string;
//   email: string;
//   createdAt: Date;
//   updatedAt: Date;
// }

// interface IUserEdge {
//   cursor: string;
//   node: IUser;
// }

// interface IUserConnection {
//   edges: string;
//   nodes: UserEntity;
//   pageInfo: IPageInfo;
//   totalCount: number;
// }

export async function getCursorPaginated(args: IUserCursorPaginatedArgs) {
  const { before, after, first, sortDirection, sortField } = args;
  return userRepository.getCursorPaginated(args);
}
