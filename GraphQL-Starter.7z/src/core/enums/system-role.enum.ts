export enum SystemRole {
  SUPER_ADMINISTRATOR = 'Super Administrator',
}
