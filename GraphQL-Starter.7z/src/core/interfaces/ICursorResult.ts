export interface ICursorResult<M> {
  cursor: string;
  data: M;
}
