import { Maybe } from 'app-graphql-schema-types';
import { UserSortField } from '@app/core/enums';
import { OrderByDirection } from 'objection';
import { UserModel } from 'src/db/models';
import { UserEntity } from './user.entity';
import { userFactory } from './user.factory';
import { ICursorPaginationResult } from '@app/core/interfaces';

async function getById(id: string): Promise<UserEntity> {
  const user = await UserModel.query().findById(id);
  const userEntity = userFactory.toEntity(user);
  return userEntity;
}

async function getByIds(ids: string[]): Promise<UserEntity[]> {
  const users = await UserModel.query().findByIds(ids);
  const userEntities = users.map((x) => userFactory.toEntity(x));
  return userEntities;
}

interface IUserCursorPaginatedArgs {
  before?: Maybe<string>;
  after?: Maybe<string>;
  first: number;
  sortDirection: OrderByDirection;
  sortField: UserSortField;
}

async function getCursorPaginated(args: IUserCursorPaginatedArgs): Promise<ICursorPaginationResult<UserModel>> {
  const { before, after, first, sortDirection, sortField } = args;
  const query = UserModel.query().orderBy(sortField, sortDirection).limit(first);
  if (before) {
    return query.previousCursorPage(before);
  }

  return query.nextCursorPage(after);
}

export const userRepository = {
  getById,
  getByIds,
  getCursorPaginated,
};
