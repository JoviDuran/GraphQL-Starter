import { GQL_User } from 'app-graphql-schema-types';
import { UserModel } from 'src/db/models';
import { UserDTO } from './user.dto';
import { UserEntity } from './user.entity';

export function toDTO(userEntity: UserEntity) {
  const { id, firstName, middleName, lastName, fullName, email, username, permissions, updatedAt, createdAt } = userEntity;
  const userDTO: UserDTO = {
    id,
    firstName,
    middleName,
    lastName,
    fullName,
    email,
    username,
    permissions,
    updatedAt,
    createdAt,
  };

  return userDTO;
}

export function toEntity(userModel: UserModel) {
  const { id, firstName, middleName, lastName, email, username, updatedAt, createdAt } = userModel;
  const userEntity: UserEntity = {
    id,
    firstName,
    lastName,
    email,
    middleName,
    username,
    updatedAt,
    createdAt,
  };

  return userEntity;
}

export function toGQL(user: UserEntity) {
  const { id, firstName, middleName, lastName, fullName, email, username, permissions, updatedAt, createdAt } = user;
  const userGQL: GQL_User = {
    id,
    firstName,
    middleName,
    lastName,
    fullName,
    email,
    username,
    permissions,
    updatedAt,
    createdAt,
  };

  return userGQL;
}
export const userFactory = {
  toDTO,
  toEntity,
  toGQL,
};
