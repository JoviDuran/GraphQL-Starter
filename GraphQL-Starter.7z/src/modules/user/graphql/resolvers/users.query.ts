import { GQL_QueryResolvers, GQL_UserConnection, GQL_UserEdge } from '@app/graphql-schema-types';
import { UserSortField, SortDirection } from '@app/core/enums';
import { createGQL_User } from '@app/core/factories/graphql';
import { getCursorPaginated } from 'src/user-cases/user/get-cursor-paginated';

export const usersResolver: GQL_QueryResolvers['users'] = async (root, args, { services }) => {
  const result = await getCursorPaginated({
    before: args.before,
    after: args.after,
    first: args.first,
    sortDirection: args.sortBy?.direction ?? SortDirection.ASC,
    sortField: args.sortBy?.field ?? UserSortField.CREATED_AT,
  });

  const userConnection: GQL_UserConnection = {
    edges: result.results.map<GQL_UserEdge>((x) => ({
      cursor: x.cursor,
      node: createGQL_User(x.data),
    })),
    nodes: result.results.map((x) => createGQL_User(x.data)),
    pageInfo: result.pageInfo,
    totalCount: result.totalCount,
  };

  // TODO: Refactor this

  return userConnection;
};
