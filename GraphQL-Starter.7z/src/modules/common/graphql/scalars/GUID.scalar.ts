import { GUIDResolver } from 'graphql-scalars';

export const GUID = GUIDResolver;
