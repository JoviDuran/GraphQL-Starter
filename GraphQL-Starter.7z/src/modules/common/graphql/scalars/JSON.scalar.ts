import { JSONResolver } from 'graphql-scalars';

export const JSON = JSONResolver;
